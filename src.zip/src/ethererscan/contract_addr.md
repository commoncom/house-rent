House Contract Address| 0x92bbb2a177e747620c27649aee88c14ecd7221f5

register contract address || 0x4d30815046594e485e008bbc0bebec76d9bc2714

token contract address || 0xfed21ab2993faa0e0b2ab92752428d96370d4889

remark contract address ||0xb7fdf357abf21d7d6aa0e956c2a4ba38651025f9

Auth contract address || 0x0455633466ab2091171489c4c85103b530371bdb