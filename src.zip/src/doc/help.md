linux kill a progress according to port ||
netstat -nlp | grep :3306