GetToken.js 
1. Cannt get the token balance because of linux cannt connect the network success.
2. Private key format is error, it should add "0x" before private key, such as "0x5....".
Error: Returned error: insufficient funds for gas * price + value 

